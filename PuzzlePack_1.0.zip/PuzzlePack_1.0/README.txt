Thanks for purchasing my asset pack!

You can:
- Use these assets in both non-commercial and commercial projects
- Edit the tiles to fit your needs
- Share these assets with a friend or two (who can NOT share them further without purchasing the pack themselves)

You can not:
- Directly sell the assets in their original or edited form
- Directly distribute the assets to more than 2 persons


You are not required to give credits, but it would be greatly appreciated.
If you do, please credit "iClaimThisName" and/or leave a link to my itchio page: https://iclaimthisname.itch.io

Again, thank you so much for purchasing my pack! If you end up making something with it, feel free to share it with me, as I would love to see it :D